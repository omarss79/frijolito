<?php
$SITE_URL  = "http://localhost/omars/frijolitodelasuerte3/";
$SITE_NAME = "Frijolito de la Suerte";
?>